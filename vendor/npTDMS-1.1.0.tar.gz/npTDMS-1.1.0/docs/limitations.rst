Limitations
===========

npTDMS currently doesn't support reading TDMS files with XML headers (TDM files),
or files with extended precision floating point data.
