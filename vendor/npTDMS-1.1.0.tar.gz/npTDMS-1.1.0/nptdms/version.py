__version_info__ = (1, 1, 0)
__version__ = '.'.join('%d' % d for d in __version_info__)
